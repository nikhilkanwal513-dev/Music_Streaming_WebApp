DB_SERVER = 'localhost'
DB_USER = 'root'
DB_PASS = 'T5zh22qa!'
DB = 'streamingdatabase'