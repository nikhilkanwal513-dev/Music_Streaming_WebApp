use streamingdatabase;

INSERT INTO paymentplans VALUES(0, 60, "Yearly");
INSERT INTO paymentplans VALUES(0, 5, "Monthly");
INSERT INTO paymentplans VALUES(0, 0, "Free");