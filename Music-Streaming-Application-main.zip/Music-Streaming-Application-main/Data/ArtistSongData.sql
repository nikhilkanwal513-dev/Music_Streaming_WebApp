use streamingdatabase;

-- Kanye
INSERT INTO artistsong VALUES(1, 1);
INSERT INTO artistsong VALUES(1, 2);
INSERT INTO artistsong VALUES(1, 3);
INSERT INTO artistsong VALUES(1, 4);
INSERT INTO artistsong VALUES(1, 5);
INSERT INTO artistsong VALUES(1, 6);
INSERT INTO artistsong VALUES(1, 7);

-- Kanye
INSERT INTO artistsong VALUES(1, 8);
INSERT INTO artistsong VALUES(1, 9);
INSERT INTO artistsong VALUES(1, 10);
INSERT INTO artistsong VALUES(1, 11);
INSERT INTO artistsong VALUES(1, 12);
INSERT INTO artistsong VALUES(1, 13);
INSERT INTO artistsong VALUES(1, 14);

-- Pusha T
INSERT INTO artistsong VALUES(2, 15);
INSERT INTO artistsong VALUES(2, 16);
INSERT INTO artistsong VALUES(2, 17);
INSERT INTO artistsong VALUES(2, 18);
INSERT INTO artistsong VALUES(2, 19);
INSERT INTO artistsong VALUES(2, 20);
INSERT INTO artistsong VALUES(2, 21);
INSERT INTO artistsong VALUES(2, 22);
INSERT INTO artistsong VALUES(2, 23);
INSERT INTO artistsong VALUES(2, 24);
INSERT INTO artistsong VALUES(2, 25);
INSERT INTO artistsong VALUES(2, 26);

-- Bjork
INSERT INTO artistsong VALUES(3, 27);
INSERT INTO artistsong VALUES(3, 28);
INSERT INTO artistsong VALUES(3, 29);
INSERT INTO artistsong VALUES(3, 30);
INSERT INTO artistsong VALUES(3, 31);
INSERT INTO artistsong VALUES(3, 32);
INSERT INTO artistsong VALUES(3, 33);
INSERT INTO artistsong VALUES(3, 34);
INSERT INTO artistsong VALUES(3, 35);
INSERT INTO artistsong VALUES(3, 36);
INSERT INTO artistsong VALUES(3, 37);

-- Harry Styles
INSERT INTO artistsong VALUES(4, 38);
INSERT INTO artistsong VALUES(4, 39);
INSERT INTO artistsong VALUES(4, 40);
INSERT INTO artistsong VALUES(4, 41);
INSERT INTO artistsong VALUES(4, 42);
INSERT INTO artistsong VALUES(4, 43);
INSERT INTO artistsong VALUES(4, 44);
INSERT INTO artistsong VALUES(4, 45);
INSERT INTO artistsong VALUES(4, 46);
INSERT INTO artistsong VALUES(4, 47);
INSERT INTO artistsong VALUES(4, 48);
INSERT INTO artistsong VALUES(4, 49);
INSERT INTO artistsong VALUES(4, 50);