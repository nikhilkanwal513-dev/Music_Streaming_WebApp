use streamingdatabase;

-- Ye
INSERT INTO albumsong VALUES(1, 1);
INSERT INTO albumsong VALUES(1, 2);
INSERT INTO albumsong VALUES(1, 3);
INSERT INTO albumsong VALUES(1, 4);
INSERT INTO albumsong VALUES(1, 5);
INSERT INTO albumsong VALUES(1, 6);
INSERT INTO albumsong VALUES(1, 7);

-- Kids See Ghosts
INSERT INTO albumsong VALUES(2, 8);
INSERT INTO albumsong VALUES(2, 9);
INSERT INTO albumsong VALUES(2, 10);
INSERT INTO albumsong VALUES(2, 11);
INSERT INTO albumsong VALUES(2, 12);
INSERT INTO albumsong VALUES(2, 13);
INSERT INTO albumsong VALUES(2, 14);

-- Its Almost Dry
INSERT INTO albumsong VALUES(3, 15);
INSERT INTO albumsong VALUES(3, 16);
INSERT INTO albumsong VALUES(3, 17);
INSERT INTO albumsong VALUES(3, 18);
INSERT INTO albumsong VALUES(3, 19);
INSERT INTO albumsong VALUES(3, 20);
INSERT INTO albumsong VALUES(3, 21);
INSERT INTO albumsong VALUES(3, 22);
INSERT INTO albumsong VALUES(3, 23);
INSERT INTO albumsong VALUES(3, 24);
INSERT INTO albumsong VALUES(3, 25);
INSERT INTO albumsong VALUES(3, 26);

-- Post
INSERT INTO albumsong VALUES(4, 27);
INSERT INTO albumsong VALUES(4, 28);
INSERT INTO albumsong VALUES(4, 29);
INSERT INTO albumsong VALUES(4, 30);
INSERT INTO albumsong VALUES(4, 31);
INSERT INTO albumsong VALUES(4, 32);
INSERT INTO albumsong VALUES(4, 33);
INSERT INTO albumsong VALUES(4, 34);
INSERT INTO albumsong VALUES(4, 35);
INSERT INTO albumsong VALUES(4, 36);
INSERT INTO albumsong VALUES(4, 37);

-- Harrys House
INSERT INTO albumsong VALUES(5, 38);
INSERT INTO albumsong VALUES(5, 39);
INSERT INTO albumsong VALUES(5, 40);
INSERT INTO albumsong VALUES(5, 41);
INSERT INTO albumsong VALUES(5, 42);
INSERT INTO albumsong VALUES(5, 43);
INSERT INTO albumsong VALUES(5, 44);
INSERT INTO albumsong VALUES(5, 45);
INSERT INTO albumsong VALUES(5, 46);
INSERT INTO albumsong VALUES(5, 47);
INSERT INTO albumsong VALUES(5, 48);
INSERT INTO albumsong VALUES(5, 49);
INSERT INTO albumsong VALUES(5, 50);