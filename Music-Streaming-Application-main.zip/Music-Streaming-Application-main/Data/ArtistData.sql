use streamingdatabase;

INSERT INTO artists VALUES(1, "Kanye West");
INSERT INTO artists VALUES(2, "Pusha T");
INSERT INTO artists VALUES(3, "Bjork");
INSERT INTO artists VALUES(4, "Harry Styles");