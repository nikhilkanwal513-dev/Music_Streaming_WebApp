use streamingdatabase;

-- Ye
INSERT INTO genresong VALUES(2, 1);
INSERT INTO genresong VALUES(2, 2);
INSERT INTO genresong VALUES(2, 3);
INSERT INTO genresong VALUES(2, 4);
INSERT INTO genresong VALUES(2, 5);
INSERT INTO genresong VALUES(2, 6);
INSERT INTO genresong VALUES(2, 7);

-- Kids See Ghosts
INSERT INTO genresong VALUES(1, 8);
INSERT INTO genresong VALUES(1, 9);
INSERT INTO genresong VALUES(1, 10);
INSERT INTO genresong VALUES(1, 11);
INSERT INTO genresong VALUES(1, 12);
INSERT INTO genresong VALUES(1, 13);
INSERT INTO genresong VALUES(1, 14);

-- Its Almost Dry
INSERT INTO genresong VALUES(1, 15);
INSERT INTO genresong VALUES(1, 16);
INSERT INTO genresong VALUES(1, 17);
INSERT INTO genresong VALUES(1, 18);
INSERT INTO genresong VALUES(1, 19);
INSERT INTO genresong VALUES(1, 20);
INSERT INTO genresong VALUES(1, 21);
INSERT INTO genresong VALUES(1, 22);
INSERT INTO genresong VALUES(1, 23);
INSERT INTO genresong VALUES(1, 24);
INSERT INTO genresong VALUES(1, 25);
INSERT INTO genresong VALUES(1, 26);

-- Post
INSERT INTO genresong VALUES(4, 27);
INSERT INTO genresong VALUES(4, 28);
INSERT INTO genresong VALUES(4, 29);
INSERT INTO genresong VALUES(4, 30);
INSERT INTO genresong VALUES(4, 31);
INSERT INTO genresong VALUES(4, 32);
INSERT INTO genresong VALUES(4, 33);
INSERT INTO genresong VALUES(4, 34);
INSERT INTO genresong VALUES(4, 35);
INSERT INTO genresong VALUES(4, 36);
INSERT INTO genresong VALUES(4, 37);

-- Harrys House
INSERT INTO genresong VALUES(4, 38);
INSERT INTO genresong VALUES(4, 39);
INSERT INTO genresong VALUES(4, 40);
INSERT INTO genresong VALUES(4, 41);
INSERT INTO genresong VALUES(4, 42);
INSERT INTO genresong VALUES(4, 43);
INSERT INTO genresong VALUES(4, 44);
INSERT INTO genresong VALUES(4, 45);
INSERT INTO genresong VALUES(4, 46);
INSERT INTO genresong VALUES(4, 47);
INSERT INTO genresong VALUES(4, 48);
INSERT INTO genresong VALUES(4, 49);
INSERT INTO genresong VALUES(4, 50);