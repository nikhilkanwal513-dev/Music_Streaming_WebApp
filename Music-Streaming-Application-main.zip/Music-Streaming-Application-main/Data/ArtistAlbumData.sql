-- Kanye
INSERT INTO artistalbum VALUES(1, 1); 
INSERT INTO artistalbum VALUES(1, 2); 

-- Pusha T
INSERT INTO artistalbum VALUES(2, 3); 

-- Bjork
INSERT INTO artistalbum VALUES(3, 4); 

-- Harry Styles
INSERT INTO artistalbum VALUES(4, 5); 
