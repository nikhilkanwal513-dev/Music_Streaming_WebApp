INSERT INTO genres VALUES(1, "rap");
INSERT INTO genres VALUES(2, "hip-hop");
INSERT INTO genres VALUES(3, "rock");
INSERT INTO genres VALUES(4, "pop");