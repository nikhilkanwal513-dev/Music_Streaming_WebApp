use streamingdatabase;

INSERT INTO albums VALUES(1, "Kids See Ghosts", "2018-06-08", "00:23:52", "/covers/ksg.png");
INSERT INTO albums VALUES(2, "Ye", "2018-06-01", "00:23:43", "/covers/ye.jpeg");
INSERT INTO albums VALUES(3, "It's Almost Dry", "2022-04-22", "00:35:53", "/covers/itsalmostdry.png");
INSERT INTO albums VALUES(4, "Post", "1995-06-13", "00:46:04", "/covers/post.png");
INSERT INTO albums VALUES(5, "Harrys House", "2022-05-20", "00:41:48", "/covers/harryshouse.png");
